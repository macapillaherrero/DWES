
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<?php
/* Actividad 1 */
echo "<h1>¡Mi primer script en PHP!</h1>" ?>

  <div>
<?php
/*   
    $foo = 10; // integer
    echo "foo " .$foo."<br>";
    $bar = (boolean) !$foo; // boolean
    echo $bar."<br>";
    $str = "$foo"; // string
    echo $str."<br>";
    $fst = (string) $foo; // string
    echo $fst."<br>";
    $foo = 'Hola'; // string
    echo $foo."<br>";   

    $j = "5" . "10"; // Warning
    $p = $j - 5; // 15
    echo $p."<br>";
    echo $j;
*/

/* Actividad 2 */

$nombre = "Oscar";
$anio = "2025";
echo "Hola, mi nombre es $nombre y el año actual es $anio" . "<br>" . "<br>";


/* Actividad 3 */

$num1 = 15;
$num2 = 5;
echo "Suma: " . ($num1 + $num2) . "<br>";
echo "Resta: " . ($num1 - $num2) . "<br>";  
echo "Multiplicación: " . ($num1 * $num2) . "<br>";


/* Actividad 4 */


$num1 = 15; // integer Asignamos un valor entero a la variable $num1
$num2 = 5; // integer Asignamos un valor entero a la variable $num2
echo "Suma: " . ($num1 + $num2) . "<br>"; // Realizamos la suma de $num1 y $num2 y mostramos el resultado
echo "Resta: " . ($num1 - $num2) . "<br>";  // Realizamos la resta de $num1 y $num2 y mostramos el resultado
echo "Multiplicación: " . ($num1 * $num2) . "<br>";// Realizamos la multiplicación de $num1 y $num2 y mostramos el resultado

/* Actividad 5 */

$temp = 30; // integer Asignamos un valor entero a la variable $temp
if ($temp > 25) {
    echo "Que calor hace!" . "<br>"; // Si la temperatura es mayor a 25, mostramos este mensaje
} else {
    echo "La temperatura es agradable " . "<br>"; // Si la temperatura es 25 o menosr, mostramos este mensaje
}




?>
</div> 

    
</body>
</html>